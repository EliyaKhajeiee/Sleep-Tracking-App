--Readme document for *Eliya Khajeie, Zachary Miszkiewicz*, *ekhajeie@uci.edu, zmiszkie@uci.edu*, *ekhajeie,zmiszkie*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

20/20
- 3/3 The ability to log overnight sleep
- 3/3 The ability to log sleepiness during the day
- 3/3 The ability to view these two categories of logged data
- 3/3 Either using a native device resource or backing up logged data
- 3/3 Following good principles of mobile design
- 3/3 Creating a compelling app
- 2/2 A readme and demo video which explains how these features were implemented and their design rationale

2. How long, in hours, did it take you to complete this assignment?
About 15 hours, in total with testing and making sure the app is working properly through all different platforms. 


3. What online resources did you consult when completing this assignment? (list specific URLs)
We used Geeks4Geeks, https://www.geeksforgeeks.org/css-buttons/ to get some buttons we wanted for our html. We used google to find photos
for some of our background which we thought was fitting for a sleeping app. We also used the Ionic Components page to find a lot of our HTML and CSS 
data from the given ones. For example the scroll wheel. 


4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
None other than both of us as partners 

5. Is there anything special we need to know in order to run your code?
There shouldn't be anything specific. We are running it on a Windows Platform with all the necessities downloaded. 


--Aim for no more than two sentences for each of the following questions.--


6. Did you design your app with a particular type of user in mind? If so, whom?
We had in mind the use of this design for a reaserch group, like a participants of a science experiment for sleeping using this app. 
With this in mind we made our app easy to navigate and easy to log things to view the data. 


7. Did you design your app specifically for iOS or Android, or both?
We designed it for both, while testing with different resolutions and an emulator worked for both platforms. 


8. How can a person log overnight sleep in your app? Why did you choose to support logging overnight sleep in this way?
A person can log their overnight sleep by choosing a scroll wheel for their bedtime and wakeup-time and being able to log the data with a 
simple button. We chose this feature because it is easy to use, and especially on mobile devices it is a lot easier to navigate a scroll wheel
and buttons as opposed to just inputting data in a box, it also gets stored in the json file and the log tab. 


9. How can a person log sleepiness during the day in your app? Why did you choose to support logging sleepiness in this way?
A person can log their sleepiness during the day by choosing how they feel from a selector of 1-7, and the time in which they are feeling this way.
Similar to the last answer we made this in mind of mobile users being super easy to just select values at a certain time of how they feeling. And this will get logged into the
json file and the log tab. 


10. How can a person view the data they logged in your app? Why did you choose to support viewing logged data in this way?
The person can view the data simply by click the tab3 which is the viewlogs tab. It is a simple overlay which shows exactly
all the things you logged at when. We went with this simple design because especially on mobile devices a good principle of design is 
simplicity so the user can fetch the exact data they need easily. 


11. Which feature choose--using a native device resource, backing up logged data, or both?
We chose to do the backing up logged data and we saved the data into a json file, which is saved in your local storage. This was the best choice for us as we both 
were very familar with how saving data worked as we have worked with jsons a lot and made it easy for the user to be able to access this in a few json
formatted file. 


12. If you used a native device resource, what feature did you add? How does this feature change the app's experience for a user?
N/A


13. If you backed up logged data, where does it back up to?
We backed it up into a json file on your local storage. Loading in the applications section of the console for our website. Everything is shown in the demo video.

14. How does your app implement or follow principles of good mobile design?
Our app adheres to good mobile design principles by featuring a simple, user-friendly interface with responsive design for various screen sizes. 
Consistent visual elements and clear feedback mechanisms ensure a cohesive and intuitive user experience. 
Accessibility considerations further enhance usability, making the app accessible to all users.
