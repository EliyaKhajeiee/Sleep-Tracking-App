import { Component } from '@angular/core';
import { StanfordSleepinessData } from '../../data/stanford-sleepiness-data';
import { AlertController } from '@ionic/angular';
import { SleepService } from 'src/services/sleep.service';
@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  selectedSleepinessLevel: number | undefined;
  selectedDateTime: string | undefined;
  feeling: string | undefined;
  loggedSleepiness!: boolean | false;
  sleepinessData: StanfordSleepinessData | undefined;

  constructor(public alertController: AlertController, public sleep:SleepService) {}
  logSleepiness() {
    if (this.selectedSleepinessLevel && this.selectedDateTime) {
      // Convert the selectedDateTime string to a Date object
      const dateTime = new Date(this.selectedDateTime);

      // Create an instance of StanfordSleepinessData with the selected sleepiness level and logged date
      this.sleepinessData = new StanfordSleepinessData(this.selectedSleepinessLevel, dateTime);

      // Get the summary string which represents how the person should be feeling
      this.feeling = this.sleepinessData.summaryString();

      this.presentAlert();
      }
    }
  

  undoSleep() {
    this.loggedSleepiness = false;

  }

  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Logger',
      message: 'Your sleepiness has been logged.',
      buttons: [{
        text: 'OK',
        role: 'ok',
        cssClass: 'secondary',
        handler: () => 
        {
          if (this.sleepinessData){
            this.sleep.logSleepinessData(this.sleepinessData);
            this.loggedSleepiness = true;
          }
          // You can put any action you want here for the cancel button
        }
      }, 
      {
        text: 'UNDO',
        role: 'undo',
        cssClass: 'secondary',
        handler: () => {
          this.undoSleep();
        }
      }]
    });
  
    await alert.present();
  }
}
