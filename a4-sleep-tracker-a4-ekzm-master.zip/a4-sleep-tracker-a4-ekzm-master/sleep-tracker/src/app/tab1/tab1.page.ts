import { Component } from '@angular/core';
import { OvernightSleepData } from '../../data/overnight-sleep-data';
import { AlertController } from '@ionic/angular';
import { SleepService } from 'src/services/sleep.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  selectedBedtime: Date | undefined;
  selectedWakeup: Date | undefined;
  sleepDuration: string | undefined;
  formattedDate: string | undefined;
  logSleepPressed!: boolean | false;
  overnightSleep: OvernightSleepData | undefined;
  sleepService: SleepService | undefined;

  constructor(public alertController: AlertController, public sleep: SleepService) {
    this.sleepService = sleep;
  }

  calculateSleepDuration() {
    console.log(this.selectedBedtime, "Bed");
    console.log(this.selectedWakeup, "Wake");
    if (this.selectedBedtime && this.selectedWakeup) {
      console.log("HITS:");
      this.selectedBedtime = new Date(this.selectedBedtime);
      this.selectedWakeup = new Date(this.selectedWakeup);
      this.overnightSleep = new OvernightSleepData(this.selectedBedtime, this.selectedWakeup);
      this.sleepDuration = this.overnightSleep.summaryString();
    }
  }

  formatDate() {
    if (this.selectedBedtime && this.selectedWakeup) {
      const overnightSleep = new OvernightSleepData(this.selectedBedtime, this.selectedWakeup);
      this.formattedDate = overnightSleep.dateString();
    }
  }

  logSleep() {
    if (this.selectedBedtime && this.selectedWakeup){
      
      // this is where we have to log our data
      if (this.overnightSleep){
        //this.sleepService.logOvernightData(new OvernightSleepData(new Date('February 18, 2021 01:03:00'), new Date('February 18, 2021 09:25:00')));
        this.presentAlert();
      }
    }
  }

  undoSleep() {
    this.logSleepPressed = false;
  }

  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Logger',
      message: 'Your overnight sleep has been logged.',
      buttons: [{
        text: 'OK',
        role: 'ok',
        cssClass: 'secondary',
        handler: () => 
        {
          if (this.overnightSleep){
            this.sleep.logOvernightData(this.overnightSleep);
            this.logSleepPressed = true;
          }
          // You can put any action you want here for the cancel button
        }
      }, 
      {
        text: 'UNDO',
        role: 'undo',
        cssClass: 'secondary',
        handler: () => 
        {
          console.log("Pressed undo")
          this.undoSleep();
          // You can put any action you want here for the cancel button
        }
      }]
    });
  
    await alert.present();
  }

}
