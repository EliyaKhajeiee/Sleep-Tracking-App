import { Component } from '@angular/core';
import { SleepService } from 'src/services/sleep.service';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  sleepData: any[] = [];
  moodData: any[] = [];

  constructor(public sleepService: SleepService) {}

  ionViewWillEnter() {
    this.displayOvernight();
    this.displaySleepiness();
  }

  displayOvernight() {
    this.sleepData = [];
     // Clear sleepData array before updating
    for (let data of SleepService.AllOvernightData) {
      this.sleepData.push({
        date: data.dateString(),
        amountSlept: data.summaryString()
      });
    }
     // Log sleepData to verify
  }

  displaySleepiness() {
    this.moodData = [];
    
    for (let data of SleepService.AllSleepinessData) {
      console.log(data);
      this.moodData.push({
        date: data.loggedAt,
        feeling: data.summaryString()
      });
    
    }
  }

}
