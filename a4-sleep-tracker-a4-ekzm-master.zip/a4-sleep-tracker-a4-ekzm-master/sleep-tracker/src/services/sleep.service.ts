import { Injectable } from '@angular/core';
import { SleepData } from '../data/sleep-data';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { File } from '@ionic-native/file/ngx';
import { Platform } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class SleepService {
  private static LoadDefaultData: boolean = true;
  public static AllSleepData: SleepData[] = [];
  public static AllOvernightData: OvernightSleepData[] = [];
  public static AllSleepinessData: StanfordSleepinessData[] = [];
  private FILE_NAME: string = 'sleep_data'; // Include the file extension
  private FILE_DIRECTORY: string = '';

  constructor() {
    if (SleepService.LoadDefaultData) {
      this.addDefaultData();
      SleepService.LoadDefaultData = false;
    }
  }

  private addDefaultData() {
    const savedData = localStorage.getItem(this.FILE_NAME);
    if (savedData) {
      const jsonData = JSON.parse(savedData);
      //SleepService.AllSleepData = jsonData.allSleepData;
      for (var i of jsonData.allOvernightData){
        this.logOvernightData(new OvernightSleepData(new Date(i['sleepStart']), new Date(i['sleepEnd'])));
      }
      for (var i of jsonData.allSleepinessData){
        this.logSleepinessData(new StanfordSleepinessData(parseInt(i['loggedValue']), new Date(i['loggedAt'])));
      }
      
      console.log('Sleep data loaded from localStorage.');
    } else {
      console.log('No saved sleep data found in localStorage.');
    }
  }

  public logOvernightData(sleepData: OvernightSleepData) {
    SleepService.AllSleepData.push(sleepData);
    SleepService.AllOvernightData.push(sleepData);
    this.saveSleepDataToJson();
  }

  public logSleepinessData(sleepData: StanfordSleepinessData) {
    SleepService.AllSleepData.push(sleepData);
    SleepService.AllSleepinessData.push(sleepData);
    this.saveSleepDataToJson();
  }


  private saveSleepDataToJson() {
    const jsonData = {
      allSleepData: SleepService.AllSleepData,
      allOvernightData: SleepService.AllOvernightData,
      allSleepinessData: SleepService.AllSleepinessData
    };
    // Convert JSON to string
    const jsonString = JSON.stringify(jsonData);

    // Save data to localStorage
    localStorage.setItem(this.FILE_NAME, jsonString);

    console.log('Sleep data saved to localStorage.');
  }
}
